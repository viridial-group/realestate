<script setup>
    import { ref } from 'vue'
    import FiltersBar from '@/components/FiltersBar.vue'
    
    const query = ref('')
    const type = ref('Tous')
    const status = ref('Tous')
    </script>
    
    <template>
      <FiltersBar
        :query="query"
        @update:query="query = $event"
    
        :type="type"
        @update:type="type = $event"
    
        :status="status"
        @update:status="status = $event"
      />
    </template>
    