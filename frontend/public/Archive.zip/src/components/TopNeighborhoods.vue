<template>
  <div class="top-neighborhoods">
    <h4>Quartiers populaires</h4>
    <div class="quartier-list">
      <span v-for="q in topNeighborhoods" :key="q.name" class="quartier-chip" @click="$emit('select', q.name)">
        {{ q.name }} ({{ q.count }} annonces)
      </span>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({ topNeighborhoods: Array })
</script>
