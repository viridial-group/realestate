<template>
  <div class="space-y-4">
    <AdCard v-for="ad in ads" :key="ad.id" :ad="ad" />
  </div>
</template>

<script setup>
import AdCard from './AdCard.vue'
defineProps({ ads:Array })
</script>
