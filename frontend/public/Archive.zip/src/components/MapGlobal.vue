<template>
  <div ref="mapRef" class="w-full h-[400px] rounded-lg shadow"></div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

const props = defineProps({ ads:Array })
const mapRef = ref(null)

onMounted(() => {
  const map = L.map(mapRef.value).setView([33.6,-7.6], 6)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map)

  props.ads.forEach(a => {
    if (a.lat && a.lng) {
      L.marker([a.lat,a.lng]).addTo(map).bindPopup(a.title)
    }
  })
})
</script>
