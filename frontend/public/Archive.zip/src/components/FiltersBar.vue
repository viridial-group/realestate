<template>
  <div class="bg-white rounded-2xl shadow-sm p-4 space-y-3">

    <!-- Search -->
    <input
      :value="query"
      @input="$emit('update:query', $event.target.value)"
      placeholder="Rechercher une ville, un quartier, un type…"
      class="w-full border border-gray-300 rounded-full px-5 py-3 text-base
             focus:outline-none focus:ring-2 focus:ring-blue-500"
    />

    <!-- Filters -->
    <div class="flex gap-3 flex-wrap">
      <select
        :value="type"
        @change="$emit('update:type', $event.target.value)"
        class="px-4 py-2 rounded-full border text-sm"
      >
        <option>Tous</option>
        <option>Appartement</option>
        <option>Villa</option>
        <option>Studio</option>
      </select>

      <select
        :value="status"
        @change="$emit('update:status', $event.target.value)"
        class="px-4 py-2 rounded-full border text-sm"
      >
        <option>Tous</option>
        <option>Disponible</option>
        <option>Loué</option>
        <option>Vendu</option>
      </select>
    </div>

  </div>
</template>

<script setup>
defineProps({
  query: String,
  type: String,
  status: String
})

defineEmits([
  'update:query',
  'update:type',
  'update:status'
])
</script>
