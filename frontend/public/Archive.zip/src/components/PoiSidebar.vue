<template>
    <div class="space-y-3">
      <h3 class="font-semibold text-sm text-gray-700">
        Points d’intérêt à proximité
      </h3>
  
      <div
        v-for="poi in pois"
        :key="poi.name"
        class="flex justify-between text-sm border-b pb-2"
      >
        <span>{{ poi.name }}</span>
        <span class="text-yellow-500 font-medium">
          ★ {{ poi.rating }}
        </span>
      </div>
    </div>
  </template>
  
  <script setup>
  defineProps({ pois: Array })
  </script>
  