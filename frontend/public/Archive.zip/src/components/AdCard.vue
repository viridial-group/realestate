<template>
  <div class="bg-white border rounded-lg p-4 flex gap-4">
    <div class="flex-1">
      <h3 class="text-blue-600 font-semibold">{{ ad.title }}</h3>
      <div class="font-bold">{{ formatPrice(ad.price) }} MAD</div>
      <div class="text-sm text-gray-600">{{ ad.city }} • {{ ad.type }}</div>
    </div>
    <span class="text-xs px-3 py-1 rounded-full"
      :class="statusClass">{{ ad.status }}</span>
  </div>
</template>

<script setup>
const props = defineProps({ ad:Object })

const formatPrice = p =>
  new Intl.NumberFormat('fr-FR').format(p)

const statusClass = {
  Disponible:'bg-green-100 text-green-700',
  Loué:'bg-red-100 text-red-700',
  Vendu:'bg-gray-200 text-gray-700'
}[props.ad.status]
</script>
