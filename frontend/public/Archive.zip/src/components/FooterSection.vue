<template>
    <footer class="p-4 text-center bg-gray-100 border-t border-gray-200 mt-8">
      <div class="flex justify-center gap-4 flex-wrap">
        <a href="#">Aide</a>
        <a href="#">Confidentialité</a>
        <a href="#">Conditions</a>
        <a href="#">Paramètres</a>
      </div>
      <p class="text-gray-500 mt-2 text-sm">&copy; 2026 RealEstate</p>
    </footer>
  </template>
  
  <script setup></script>
  