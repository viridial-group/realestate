<template>
  <div class="flex justify-center gap-2 mt-4">
    <button
      class="px-3 py-1 rounded border border-gray-300 disabled:opacity-50"
      :disabled="currentPage===1"
      @click="$emit('prevPage')"
    >Préc</button>

    <button
      v-for="p in totalPages" :key="p"
      @click="$emit('goToPage', p)"
      class="px-3 py-1 rounded border border-gray-300"
      :class="{'bg-blue-600 text-white border-blue-600': currentPage===p}"
    >{{ p }}</button>

    <button
      class="px-3 py-1 rounded border border-gray-300 disabled:opacity-50"
      :disabled="currentPage===totalPages"
      @click="$emit('nextPage')"
    >Suiv</button>
  </div>
</template>

<script setup>
defineProps(['currentPage','totalPages'])
defineEmits(['prevPage','nextPage','goToPage'])
</script>
