<template>
    <div class="min-h-screen bg-gray-100 text-gray-900">
      <header class="bg-white border-b p-4 text-lg font-semibold">
        Recherche immobilière
      </header>
  
      <main>
        <slot />
      </main>
  
      <footer class="border-t text-sm text-gray-500 text-center py-4">
        © 2026 • À propos • Confidentialité • Conditions
      </footer>
    </div>
  </template>
  