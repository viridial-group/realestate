import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './style.css'  // Tailwind + shadcn-vue variables
import './assets/main.css'  // Styles personnalisés composants

createApp(App).use(router).mount('#app')